import java.util.*;
class SwitchCaseDemo
{
	public static void main(String args[])
	{
		int i;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter value:=>");
		
		i = sc.nextInt();
		
		switch (i)
		{
			case 0:
				System.out.println("it is 0");
				break;
			
			case 1:
				System.out.println("it is 1");
				break;
			
			case 2:
				System.out.println("it is 2");
				break;
				
			case 3:
				System.out.println("it is 3");
				break;
			default:
				System.out.println("i is greater than 2.");

		}
	}
}