public class student 
{
	int id;
	String name;
	
	student()
	{
		System.out.println("this is default constructor");
	}
	
	student(int i,String n)
	{
		id = i;
		name = n;
	}
	
	
	public static void main(String args[])
	{
		student s = new student();
		System.out.println("\n defualt con. values \n");
		System.out.println("student id :"+ s.id + "\n student name:"+ s.name);
		
		System.out.println("parameterised con values: \n ");
		
		student stud = new student(10,"pratik");
		System.out.println("student id :"+ stud.id + "\n student name:"+ stud.name);
	}
}