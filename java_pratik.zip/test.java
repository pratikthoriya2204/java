class test 
{
	public static void main(String args[])
	{
		int a,b,c,d,total;
		float per,pr;
		
		
		System.out.println("\n\n\nmy result is :\n\n\n");
		a = 65;
		System.out.println("Enter sub 1 mark  \t " + a);
		
		b = 84;
		System.out.println("Enter sub 2 mark  \t" + b);
		
		c = 94;
		System.out.println("Enter sub 2 mark \t " + c);
		
		d = 84;
		System.out.println("Enter sub 2 mark \t " + d);
		
		total = a+b+c+d;
		
		System.out.println("total is" + total);
		
		per = total / 4;
		
		System.out.println("percentage is  "+ per);
		 
		pr = per + 15;
		
		System.out.println("percentile is  "+ pr);
		
		System.out.println("\n\n\n my friend resul is hear:  \n\n\n ");
		
		int m1,m2,m3,m4,totalf;
		float percentage,prc; 
	
		
		m1 = 70;
		System.out.println("Enter sub 1 mark  \t " + m1);
		
		m2 = 99;
		System.out.println("Enter sub 2 mark  \t" + m2);
		
		m3 = 91;
		System.out.println("Enter sub 2 mark \t " + m3);
		
		m4 = 84;
		System.out.println("Enter sub 2 mark \t " + m4);
		
		totalf = m1+m2+m3+m4;
		
		System.out.println("total is" + totalf);
		
		percentage = totalf / 4;
		
		System.out.println("percentage is  "+ percentage);
		 
		prc = percentage + 13;
		
		System.out.println("percentile is  "+ prc);
	}
}	
	
	
