import java.util.Scanner;
public class arop
{
	public static void arithmetic(float a , float b , string c)
	{
		float  n1 = a,  n1 = b,ans = 0;

		swich(s1)
		{
			case "+";
				ans = n1 + n2;
				System.out.println("sum:" + ans);
				break;
				
			case "-";
				ans = n1 - n2;
				System.out.println("sub:" + ans);
				break;
				
			default:
				System.out.println("Even + or - op");
		}
	}
	public static void main(String []args)
	{
		float a,b;
		string c;
		Scanner sc = new Scanner (System.in);
		System.out.println("enter 2 nos + op");
		a = sc.nextInt();
		b = sc.nextInt();
		c = sc.next();
		arithmetic(a,b,c);
	}	
}