class test 
{
	public static void main(String args[])
	{
		int a,b,c,d;
		float per,pr;
		
		
		int total = 0;
		int []m = new int[4];
		Scanner s = new Scanner (System.in);
		for(int i=0;i<=3;i++)
		{
			m[i] = s.nextInt();
			total  = m[i];
		}
		int per = total;
		
		
		
		
		System.out.println("\n\n\nmy result is :\n\n\n");
		a = 65;
		System.out.println("Enter sub 1 mark  \t " + a);
		
		b = 84;
		System.out.println("Enter sub 2 mark  \t" + b);
		
		c = 94;
		System.out.println("Enter sub 2 mark \t " + c);
		
		d = 84;
		System.out.println("Enter sub 2 mark \t " + d);
		
		total = a+b+c+d;
		
		System.out.println("total is" + total);
		
		per = total / 4;
		
		System.out.println("percentage is  "+ per);
		 
		pr = per + 15;
		
		System.out.println("percentile is  "+ pr);
		
		System.out.println("\n\n\n my friend resul is hear:  \n\n\n ");
	}
}