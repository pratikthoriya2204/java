
import java.util.Scanner;

public class pn2
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter a value:0");
		int a = sc.nextInt();
		if(a >= 0)
		{
			if(a == 0)
				System.out.println("number is zero");
			else
				System.out.println("number is positive");
		}
		else
		{
			System.out.println("number is nagative");
		}
	}
}